import React, { useState } from 'react';
import './app.css';
import FlashcardList from './FlashcardList';
import Dashboard from './Dashboard';

export default function App() {
  const [flashcards, setFlashcards] = useState(SAMPLE_FLASHCARDS);
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % flashcards.length);
  };

  const handlePrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + flashcards.length) % flashcards.length);
  };

  return (
    <div>
      <FlashcardList flashcards={[flashcards[currentIndex]]} />
      <div className="button-container">
        <button onClick={handlePrevious}>Previous</button>
        <button onClick={handleNext}>Next</button>
      </div>
      <Dashboard flashcards={flashcards} setFlashcards={setFlashcards} />
    </div>
  );
}

const SAMPLE_FLASHCARDS = [
  {
    id: 1,
    question: "What is the primary purpose of React?",
    answer: 'B) To build user interfaces for web applications',
    option: [
      "A) To manage server-side applications",
      "B) To build user interfaces for web applications",
      "C) To perform data analysis",
      "D) To handle database operations"
    ]
  },
  {
    id: 2,
    question: "What does JSX stand for?",
    answer: 'B) JavaScript XML',
    option: [
      "A) JavaScript Syntax Extension",
      "B) JavaScript XML",
      "C) JavaScript Syntax Extra",
      "D) JavaScript Execution"
    ]
  },
  {
    id: 3,
    question: "What is React used for?",
    answer: 'C) User interfaces',
    option: [
      "A) Server-side apps",
      "B) Data analysis",
      "C) User interfaces",
      "D) Database ops"
    ]
  },
  {
    id: 4,
    question: "What does useEffect do?",
    answer: 'B) Handles side effects',
    option: [
      "A) Manages state",
      "B) Handles side effects",
      "C) Provides context",
      "D) Optimizes performance"
    ]
  }
];
