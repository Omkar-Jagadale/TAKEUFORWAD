import React, { useState } from 'react';

export default function Dashboard({ flashcards, setFlashcards }) {
  const [newFlashcard, setNewFlashcard] = useState({
    question: '',
    answer: '',
    option: ['', '', '', '']
  });

  const handleAddFlashcard = () => {
    setFlashcards([...flashcards, { ...newFlashcard, id: flashcards.length + 1 }]);
    setNewFlashcard({ question: '', answer: '', option: ['', '', '', ''] });
  };

  const handleEditFlashcard = (index, field, value) => {
    const updatedFlashcards = [...flashcards];
    updatedFlashcards[index][field] = value;
    setFlashcards(updatedFlashcards);
  };

  const handleDeleteFlashcard = (index) => {
    const updatedFlashcards = flashcards.filter((_, i) => i !== index);
    setFlashcards(updatedFlashcards);
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <div>
        <input
          type="text"
          placeholder="Question"
          value={newFlashcard.question}
          onChange={(e) => setNewFlashcard({ ...newFlashcard, question: e.target.value })}
        />
        <input
          type="text"
          placeholder="Answer"
          value={newFlashcard.answer}
          onChange={(e) => setNewFlashcard({ ...newFlashcard, answer: e.target.value })}
        />
        {newFlashcard.option.map((opt, i) => (
          <input
            key={i}
            type="text"
            placeholder={`Option ${i + 1}`}
            value={opt}
            onChange={(e) => {
              const options = [...newFlashcard.option];
              options[i] = e.target.value;
              setNewFlashcard({ ...newFlashcard, option: options });
            }}
          />
        ))}
        <button onClick={handleAddFlashcard}>Add Flashcard</button>
      </div>
      <div>
        {flashcards.map((flashcard, index) => (
          <div key={flashcard.id}>
            <input
              type="text"
              value={flashcard.question}
              onChange={(e) => handleEditFlashcard(index, 'question', e.target.value)}
            />
            <input
              type="text"
              value={flashcard.answer}
              onChange={(e) => handleEditFlashcard(index, 'answer', e.target.value)}
            />
            {flashcard.option.map((opt, i) => (
              <input
                key={i}
                type="text"
                value={opt}
                onChange={(e) => {
                  const options = [...flashcard.option];
                  options[i] = e.target.value;
                  handleEditFlashcard(index, 'option', options);
                }}
              />
            ))}
            <button onClick={() => handleDeleteFlashcard(index)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}
